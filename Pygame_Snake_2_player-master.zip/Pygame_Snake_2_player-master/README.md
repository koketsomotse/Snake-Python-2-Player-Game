# Pygame_Snake_2_player

This is a 2 player version(with a split screen) of the classic snake game. This is a non object oriented code since this 
was written when I learning how to code. This is not a complete game i am planning to add some more features to it and a 
combact mode too.

CONTROLS
Player 1 movement controls are the arrow keys .
Player 2 movement controls are the ASWD keys .
